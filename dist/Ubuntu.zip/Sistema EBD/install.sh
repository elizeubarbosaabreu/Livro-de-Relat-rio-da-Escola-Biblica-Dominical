#!/bin/bash

# Caminho atual (de onde o script está sendo executado)
ORIGEM="$(pwd)"
DESTINO="$HOME/SistemaEBD"
DESKTOP_DIR="$HOME/.local/share/applications"

# Cria o diretório ~/SistemaEBD se não existir
mkdir -p "$DESTINO"

# Move os arquivos .txt para o diretório HOME
for txt in "$ORIGEM"/*.txt; do
    [ -e "$txt" ] && mv "$txt" "$HOME/"
done

# Copia os demais arquivos (não .txt) para ~/SistemaEBD
for file in "$ORIGEM"/*; do
    if [[ ! "$file" =~ \.txt$ ]]; then
        cp -r "$file" "$DESTINO/"
    fi
done

# Lista de executáveis (sem extensão)
EXECUTAVEIS=("gerador_relatorio_GUI" "domingo_atual" "gera_planilhas" "lote_rel_domingos")

# Cria atalhos .desktop para cada executável
for exec in "${EXECUTAVEIS[@]}"; do
    ARQUIVO_DESKTOP="$DESKTOP_DIR/$exec.desktop"

    cat > "$ARQUIVO_DESKTOP" <<EOF
[Desktop Entry]
Name=$exec
Exec=$DESTINO/$exec
Icon=utilities-terminal
Terminal=true
Type=Application
Categories=Utility;
EOF

    chmod +x "$ARQUIVO_DESKTOP"
done

echo "✅ Instalação concluída:"
echo "  - Executáveis copiados para: $DESTINO"
echo "  - Arquivos de configuração movidos para: $HOME"
echo "  - Atalhos criados no menu de aplicativos."

